import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import FormAssignment from './FormAssignment'

function App() {

  return (
   <div>
    <FormAssignment />
   </div>
  )
}

export default App