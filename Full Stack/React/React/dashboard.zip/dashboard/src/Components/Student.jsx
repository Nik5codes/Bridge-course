import React from 'react'

const Student = () => {
  return (
    <div>
      <h2>Heyy i am Student</h2>
      
    </div>
  )
}

export default Student
