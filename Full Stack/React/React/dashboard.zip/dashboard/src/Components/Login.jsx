import React from "react";
import { useState } from "react";
import Admin from "./Admin";
import Mentor from "./Mentor";
import Student from "./Student";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const [User, setUser] = useState();
  const [Password, setPassword] = useState();
  const navigate = useNavigate();

  const handleClick=()=>{
  const user = User.trim().toLowerCase();
  
  if (user == "Admin" || user == "admin") {
    navigate("/admin");
  } else if (user == "Mentor" || user == "mentor") {
    navigate("/mentor");
  } else if (user == "Student" || user == "student") {
    navigate("/student");
  } else {
    alert("Invalid user. Please type Admin, Mentor, or Student.");
    }  
  };

  return (

    <div className="bg-lime-100 mt-44 mr-100 mb-8 ml-80 rounded-xl border-4 border-purple-400 pb-6">
      <div>
        <h2 className="bg-sky-100 pb-5 text-4xl md:text-center">LoginPage</h2>
        <br />

        <label htmlFor="">Username: </label>
        <input
          type="text"
          placeholder="Username"
          onChange={(e) => setUser(e.target.value)}
          className="bg-pink-500/[71.37%] rounded-xl pt-2 pr-4 pb-2 pl-4"
        />
        <br />
        <br />
        <label htmlFor="Password">Password: </label>
        <input
          type="password"
          placeholder="Password not required"
          onChange={(e) => setPassword(e.target.value)}
          className="bg-pink-500/[71.37%] rounded-xl pt-2 pr-4 pb-1 pl-4"
        />
        <br />
        <br />
        <button
          type="submit"
          onClick={handleClick}
          className="bg-green-200  rounded-xl border-4 border-purple-400 pt-2 pr-4 pb-2 pl-4 "
        >
          Login{" "}
        </button>
      </div>
    </div>
  );
};

export default Login;
