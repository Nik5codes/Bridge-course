import React from 'react'

const Admin = () => {
  return (
    <div>
      <h1>Admin Page</h1>
    </div>
  )
}

export default Admin
