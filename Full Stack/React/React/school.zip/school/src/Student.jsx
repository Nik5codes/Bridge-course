import React from 'react'

const Student = () => {
  return (
    <div>
      <h1>Student</h1>
    </div>
  )
}

export default Student
