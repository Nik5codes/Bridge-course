import React from 'react'

const Mentor = () => {
  return (
    <div>
      <h1>Mentor</h1>
    </div>
  )
}

export default Mentor
